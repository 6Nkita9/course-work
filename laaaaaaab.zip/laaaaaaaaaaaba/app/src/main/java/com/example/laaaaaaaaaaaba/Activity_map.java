package com.example.laaaaaaaaaaaba;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class Activity_map extends AppCompatActivity {

    int location;
    ImageView image;
    Button btn;
    int way;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);

        image = findViewById(R.id.image);

        Bundle arguments = getIntent().getExtras();

        location = Integer.parseInt(arguments.get("location").toString());

        btn = findViewById(R.id.button2);




         if (location == 4) {
             image.setImageResource(R.drawable.mega_mall_4);
         }
         else if (location == 1) {
             image.setImageResource(R.drawable.mega_mall_1);
         }
         else if (location == 2) {
             image.setImageResource(R.drawable.mega_mall_2);
         }
         else if (location == 3) {
             image.setImageResource(R.drawable.mega_mall_3);
         }
         else if (location == 5) {
             image.setImageResource(R.drawable.mega_mall_5);
         }
         else if (location == 6) {
             image.setImageResource(R.drawable.mega_mall_6);
         }
         else if (location == 7) {
             image.setImageResource(R.drawable.mega_mall_7);
         }

         btn.setOnClickListener(
                 new View.OnClickListener() {
                     @Override
                     public void onClick(View view) {
                         Intent intent2 = new Intent(getApplicationContext(),MainActivity.class);
                         startActivity(intent2);
                     }
                 }
         );



    }

}