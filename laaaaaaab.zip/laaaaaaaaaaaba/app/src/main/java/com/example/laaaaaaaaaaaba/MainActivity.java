package com.example.laaaaaaaaaaaba;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {

    Button button;
    EditText Input_1;

    int n;
    boolean b = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        button = findViewById(R.id.button);
        Input_1 = (EditText) findViewById(R.id.Input_1);

        button.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                            n = Integer.parseInt(Input_1.getText().toString());

                            if (n == 1) {
                                b = true;
                            } else if (n == 2) {
                                b = true;
                            } else if (n == 3) {
                                b = true;
                            } else if (n == 4) {
                                b = true;
                            } else if (n == 5) {
                                b = true;
                            } else if (n == 6) {
                                b = true;
                            } else if (n == 7) {
                                b = true;
                            } else {
                                b = false;
                            }

                            if (b == true) {
                                Intent intent = new Intent(getApplicationContext(), Activity_map.class);
                                intent.putExtra("location", Input_1.getText());
                                startActivity(intent);

                            } else if (b == false) {
                                Toast toast = Toast.makeText(getApplicationContext(),
                                        "you entered an invalid waypoint!", Toast.LENGTH_SHORT);
                                toast.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL, 0, 0);
                                toast.show();
                            }


                    }
                }
        );


    }
}