package com.example.laaaaaaaaaaaba;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {

    Button button;            //обозначим переменную с типом данных button
    EditText Input_1;           //обозначим переменную с типом данных edit text

    int n;                //переменная в которую помещается знаечние с EditText для дольнейшей проверки на правильность введенных данных
    boolean b = false;      // тоже переменная проверяющая правильность данных. если данные введены правильно, b == true если нет, то false

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        button = findViewById(R.id.button);                  // находим ранее обозначенные переменные по их id в коде xml
        Input_1 = (EditText) findViewById(R.id.Input_1);

        button.setOnClickListener(           // создаем слушатель кликов на кнопку
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {        // базовая конструкция OnClick

                            n = Integer.parseInt(Input_1.getText().toString());  // приводим значение введенное в edit text в тип данных int

                            if (n == 1) {            // Проверяем введенное число
                                b = true;
                            } else if (n == 2) {
                                b = true;
                            } else if (n == 3) {
                                b = true;
                            } else if (n == 4) {
                                b = true;
                            } else if (n == 5) {
                                b = true;
                            } else if (n == 6) {
                                b = true;
                            } else if (n == 7) {
                                b = true;
                            } else {
                                b = false;
                            }

                            if (b == true) { //если b==true значит число было введено правильно. Следовательно реализовываем функцию перехода на другой экран с одновременным переносом значения переменной из edit text
                                Intent intent = new Intent(getApplicationContext(), Activity_map.class);
                                intent.putExtra("location", Input_1.getText());
                                startActivity(intent);

                            } else if (b == false) {   //если b==false, значит введенное число не прошло проверку, то мы выводим тост с сообщением о неправильно введенном числе
                                Toast toast = Toast.makeText(getApplicationContext(),
                                        "you entered an invalid waypoint!", Toast.LENGTH_SHORT);
                                toast.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL, 0, 0);
                                toast.show();
                            }


                    }
                }
        );


    }
}